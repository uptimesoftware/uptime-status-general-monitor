#!/usr/bin/perl

use LWP::UserAgent;

my $hostname = shift || $ENV{UPTIME_HOSTNAME} ; 
my $ua = LWP::UserAgent->new;
my $url = 'http://' . $hostname . ':9996/status/general';
my $res = $ua->get($url);

open(MYOUTFILE, ">threads.txt");
print MYOUTFILE $res->content;
close(MYOUTFILE);

open(MYOUTFILE, "<threads.txt");
while (<MYOUTFILE>)
{
	my ($line) = $_;
	if ( /.*(\<monitors_in_queue\>)([0-9]+)(\<\/monitors_in_queue\>)/ )
	{
		$monqueue=$2;
	}
	elsif ( /.*(\<active_threads\>)([0-9]+)(\<\/active_threads\>)/ )
	{
		$activethreads=$2;
	}
	elsif ( /.*(\<pool_size\>)([0-9]+)(\<\/pool_size\>)/ )
	{
		$poolsize=$2;
	}
	elsif ( /.*(\<idle_threads\>)([0-9]+)(\<\/idle_threads\>)/ )
	{
		$idlethreads=$2;
	}
	elsif ( /.*(\<heap_total\>)([0-9]+)(\<\/heap_total\>)/ )
	{
		$heaptotal=$2;
	}
	elsif ( /.*(\<heap_free\>)([0-9]+)(\<\/heap_free\>)/ )
	{
		$heapfree=$2;
	}
	elsif ( /.*(\<heap_max\>)([0-9]+)(\<\/heap_max\>)/ )
	{
		$heapmax=$2;
	}
	elsif ( /.*(\<busy\>)([0-9]+)(\<\/busy\>)/ )
	{
		$connbusy=$2;
	}
	elsif ( /.*(\<idle\>)([0-9]+)(\<\/idle\>)/ )
	{
		$connidle=$2;
	}
	elsif ( /.*(\<total\>)([0-9]+)(\<\/total\>)/ )
	{
		$conntotal=$2;
	}
}
close(MYOUTFILE);
print "monqueue $monqueue\n";
print "activethreads $activethreads\n";
print "poolsize $poolsize\n";
print "idlethreads $idlethreads\n";
print "heaptotal $heaptotal\n";
print "heapfree $heapfree\n";
print "heapmax $heapmax\n";
print "connbusy $connbusy\n";
print "connidle $connidle\n";
print "conntotal $conntotal\n";
exit 0;
