Status - General Plug-In Monitor:

This plugin monitors general status for the data collector, including:

- Number of Monitors in the queue
- Active Threads
- Maximum Threads
- Idle Threads
- Java heap total memory
- Java heap free memory
- Java heap maximum memory
- Number of busy connections
- Number of idle connections
- Number of maximum connections
